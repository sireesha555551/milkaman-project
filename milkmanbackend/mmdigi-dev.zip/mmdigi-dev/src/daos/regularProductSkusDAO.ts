// import { getEntityManager, Repository } from "typeorm";
// //import {RegularProductSku} from "./../models/entities/suppliers";
// import{BaseDAO} from "../config/baseDAO";


// export class RegularProductSkusDAO extends BaseDAO<RegularProductSku>{
    
// public rep: Repository<RegularProductSku>;

//     constructor() {
//     super(RegularProductSku);
//         this.rep = getEntityManager().getRepository(RegularProductSku);
//     }
    

// }

    
    
    
    
    

// Object.seal(RegularProductSkusDAO);